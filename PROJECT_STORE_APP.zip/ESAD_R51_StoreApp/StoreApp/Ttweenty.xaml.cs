﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StoreApp
{
    /// <summary>
    /// Interaction logic for Ttweenty.xaml
    /// </summary>
    public partial class Ttweenty : Window
    {
        public Ttweenty()
        {
            InitializeComponent();
        }

        private void btnGoBackWelcom_Click(object sender, RoutedEventArgs e)
        {
            Welcome w = new Welcome();
            w.Show();
           
        }
    }
}
