﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace StoreApp.Models
{
    class Cricketer
    {
        
        
            public ImageSource ImageSrc { get; set; }
            public string ImageTitle { get; set; }
            public string PlayerFistName { get; set; }
            public string PlayerLastName { get; set; }
            public int Age { get; set; }
            public int Rank { get; set; }
            public string Team { get; set; }
            public double Rating { get; set; }
        
    }
}
