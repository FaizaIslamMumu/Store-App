﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StoreApp
{
    /// <summary>
    /// Interaction logic for Welcome.xaml
    /// </summary>
    public partial class Welcome : Window
    {
        

        public Welcome()
        {
            InitializeComponent();
        }

        private void btnClick_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            m.Show();
            this.Hide();

            DatePicker dp = new DatePicker();
            DateTime? selectedDate = dp.SelectedDate;
            this.Show();
            MessageBox.Show("Select Date First!");
            this.Show();
        }

        private void btnOdi_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            m.Show();
            
            DatePicker dp = new DatePicker();
            DateTime? selectedDate = dp.SelectedDate;
            this.Activate();
           
            this.Close();
           
           

        }

        private void ___btnTest__Click(object sender, RoutedEventArgs e)
        {
            Test t = new Test();
            t.Show();

            MessageBox.Show("No Update Yet!");
            this.Close();
        }

        private void btnT20_Click(object sender, RoutedEventArgs e)
        {
            Ttweenty t = new Ttweenty();
            t.Show();
            MessageBox.Show("No Update Yet!");
            this.Close();
        }
    }
}
