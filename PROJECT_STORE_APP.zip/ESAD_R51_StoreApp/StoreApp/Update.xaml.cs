﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using StoreApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace StoreApp
{
    public partial class Update : Window
    {
        MainWindow Main = new MainWindow();
        //public MainWindow mainWindow = (MainWindow)Application.Current.MainWindow; //Access MainWindow by Owner

        //public MainWindow mainWindow => (MainWindow)Owner;  //Access MainWindow by Owner

        public string filename = @"Cricketer.json";
        public FileInfo TempImageFile { get; set; }         //Using for upload image
        public FileInfo OldImageFile { get; set; }          //Using for exists image
        public Update()
        {
            InitializeComponent();
            string[] Team = new string[] { "Bangladesh", "India", "Sri Lanka", "Pakistan", "Australia", "South Africa", "West Indies", "Afghanistan", "Netherlands", "Kenya", "England", "New zealand", "Zimbabwe" }; ;
            this.cmbTeam.ItemsSource = Team;
            cmbTeam.SelectedIndex = -1;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            var Rank = Convert.ToInt32(txtRannk.Text);
            var Team = cmbTeam.SelectedItem.ToString();
            var FirstName = txtFirstName.Text;
            var LastName = txtLastName.Text;
            var Age = txtPAge.Text;
            var Rating = txtRating.Text;

            var json = File.ReadAllText(filename);
            var jsonObj = JObject.Parse(json);
            var crJson = jsonObj.GetValue("Cricketer").ToString();
            var crList = JsonConvert.DeserializeObject<List<Cricketer>>(crJson);

            foreach (var item in crList.Where(x => x.Rank == Rank))
            {
                item.Team = Team;
                item.PlayerFistName = FirstName;
                item.PlayerLastName = LastName;
                item.Age = int.Parse(Age);
                item.Rating = double.Parse(Rating);
                OldImageFile = (item.ImageTitle != "default.png") ? new FileInfo(Main.GetImagePath() + item.ImageTitle) : null;   //ternary to evaluate null if exists image is default image

                if (TempImageFile != null && OldImageFile == null)  //Check if upload image not null && exists image is null or default.png
                {
                    TempImageFile.CopyTo(Main.GetImagePath() + item.Rank + TempImageFile.Extension);
                    item.ImageTitle = item.Rank + TempImageFile.Extension;
                    TempImageFile = null;
                }
                if (OldImageFile != null && TempImageFile != null) //Check if upload image not null && old image not null. Extra -> check if old file exists in directory
                {
                    item.ImageTitle = item.Rank + TempImageFile.Extension;
                    OldImageFile.Delete();      //Delete exists image
                    TempImageFile.CopyTo(Main.GetImagePath() + Rank + TempImageFile.Extension); //Copy upload image to target directory
                    TempImageFile = null;
                }

            }

            var crArray = JArray.FromObject(crList);  //Convert List<Cricketer> to Jarray
            jsonObj["Cricketer"] = crArray;            //Set Jarray to 'Cricketer' JProperty
            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);  //Serialize data using Extension Method
            File.WriteAllText(filename, output);

            this.Close();                               //Close the current window
            Main.ShowData();                      //Call Mainwindow ShowData() Method
            Main.ShowWindow();
            MessageBox.Show("Data Updated Successfully !!");

        }

        private void btnImgModify_Click(object sender, RoutedEventArgs e)   //Upload Image
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image Files(*.jpg; *.jpeg; *.png;)|*.jpg; *.jpeg; *.png;";
            fd.Title = "Select an Image";
            if (fd.ShowDialog().Value == true)
            {
                ImgModify.Source = Main.ImageInstance(new Uri(fd.FileName));  //ImageInstance return new instance of image rather than image reference
                TempImageFile = new FileInfo(fd.FileName);
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Main.Show();
        }
    }
}
